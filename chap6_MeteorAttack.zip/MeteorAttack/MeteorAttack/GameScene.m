//
//  GameScene.m
//

#import "GameScene.h"
#import "SceneEscapeProtocol.h"

@implementation GameScene{
	
	BOOL			_isRotating;			//宇宙船回転中フラグ
	
	SKTexture*		_textureMissile;		//ミサイルのテクスチャ
	SKTexture*		_textureMeteor;			//隕石のテクスチャ
	BOOL			_gameOver;				//ゲームオーバーフラグ
	
	SKEmitterNode*	_particleFire;			//炎のパーティクル
	SKEmitterNode*	_particleSpark;			//スパークのパーティクル
	SKEmitterNode*	_particleBom;			//ボムのパーティクル
	SKEmitterNode*	_particleSmoke;			//スモークのパーティクル
}

-(id)initWithSize:(CGSize)size
{
    if (self = [super initWithSize:size])
	{
		//背景
		SKSpriteNode* space = [SKSpriteNode spriteNodeWithImageNamed:@"GameBack.png"];
		space.position = CGPointMake(self.size.width/2, self.size.height/2);
		space.name = kBackName;
		[self addChild:space];
		
		//地球
		SKSpriteNode* earth = [SKSpriteNode spriteNodeWithImageNamed:@"Earth.png"];
		earth.position = CGPointMake(self.size.width/2, earth.size.height/2);
		earth.name = kEarthName;
		[self addChild:earth];
		//物理シミュレーション
		earth.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:CGSizeMake(earth.size.width, earth.size.height/2)];
		earth.physicsBody.dynamic = NO;	//重力を無効にする
		//接触設定
		earth.physicsBody.categoryBitMask = earthCategory;		//カテゴリー（地球）
		earth.physicsBody.collisionBitMask = 0;					//接触できるオブジェクト（なし）
		
		//宇宙船
		SKSpriteNode*	spaceship = [SKSpriteNode spriteNodeWithImageNamed:@"Spaceship.png"];
		spaceship.position = CGPointMake(self.size.width/2, spaceship.size.height);
		spaceship.name = kSpaceshipName;
		[self addChild:spaceship];
		//物理シミュレーション
		spaceship.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:spaceship.size.width/2];
		spaceship.physicsBody.dynamic = NO;	//重力を無効にする
		//接触設定
		spaceship.physicsBody.categoryBitMask = spaceshipCategory;	//カテゴリー（宇宙船）
		spaceship.physicsBody.collisionBitMask = 0;				//接触できるオブジェクト（なし）
		
		//スコア
		//タイトル
		SKLabelNode *scoreTitleNode = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		scoreTitleNode.fontSize = 20;
		scoreTitleNode.text = @"SCORE";
		[self addChild:scoreTitleNode];
		scoreTitleNode.position = CGPointMake((scoreTitleNode.frame.size.width/2)+20, self.frame.size.height-30);
		//スコア
		SKLabelNode*	scoreNode = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		scoreNode.name = kScoreName;
		scoreNode.fontSize = 20;
		[self addChild:scoreNode];
		self.score = 0;
		scoreNode.position = CGPointMake(CGRectGetMidX(self.frame), self.frame.size.height-30);
		
		
		//重力を1/50にする
		self.physicsWorld.gravity = CGVectorMake(0, -(9.8*0.02));
		
		//接触デリゲート
		self.physicsWorld.contactDelegate = self;
		
		//ミサイルのテクスチャ
		_textureMissile = [SKTexture textureWithImageNamed:@"Missile.png"];
		
		//隕石のテクスチャ
		_textureMeteor = [SKTexture textureWithImageNamed:@"Meteor.png"];
		

		//隕石を一定間隔でランダムに作る
		SKAction *makeMeteors = [SKAction sequence: @[
													  [SKAction performSelector:@selector(addMeteor) onTarget:self],
													  [SKAction waitForDuration:1.8 withRange:1.6]]];
		[self runAction: [SKAction repeatActionForever:makeMeteors]];
		
		
		//隕石落下数
		SKLabelNode*	fallenNumNode = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		fallenNumNode.name = kFallenName;
		fallenNumNode.fontSize = 30;
		[self addChild:fallenNumNode];
		self.fallenNumber = 3;
		fallenNumNode.position = CGPointMake(self.frame.size.width-(fallenNumNode.frame.size.width/2)-20, self.frame.size.height-30);
		
/*
		 
		//レベル
		SKLabelNode*	levelNode = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		levelNode.name = kLevelName;
		levelNode.fontSize = 20;
		[self addChild:levelNode];
		self.level = 1;
		levelNode.position = CGPointMake(self.frame.size.width-(levelNode.frame.size.width/2)-20, self.frame.size.height-60);
 */
    }
    return self;
}

-(void)update:(CFTimeInterval)currentTime
{
	
}

//シーンがビューから取り除かれたときに呼ばれる
- (void)willMoveFromView:(SKView *)view
{
	
}

//シーンがビューに表示されたときに呼ばれる
- (void)didMoveToView:(SKView *)view
{
	
	
}

//タッチダウン
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(_gameOver){
		if([_delegate respondsToSelector:@selector(sceneEscape:)]){
			[_delegate sceneEscape:self];
		}
		return;
	}
	//宇宙船の回頭中はミサイル発射不可
	if( _isRotating==NO ){
		//タッチ位置
		UITouch *touch = [touches anyObject];
		CGPoint location = [touch locationInNode:self];
		//名前から宇宙船を検索
		SKNode*		spaceship = [self childNodeWithName:kSpaceshipName];
		//宇宙船の位置
		CGPoint	spaceship_pt = spaceship.position;
		//宇宙船の新しい角度
		CGFloat		radian = -(atan2f(location.x-spaceship_pt.x, location.y-spaceship_pt.y));
		//回転角度から回転時間を求める
		CGFloat		 diff = fabsf(spaceship.zRotation-radian);
		NSTimeInterval	time = diff * 0.3;//回転速度係数
		
		//宇宙船回頭
		_isRotating = YES;	//回転中フラグON
		SKAction*	rotate = [SKAction rotateToAngle:radian duration:time];
		[spaceship runAction:rotate completion:^{
			//宇宙船回頭後、ミサイル発射
			_isRotating = NO;	//回転中フラグOFF
			//ミサイル作成
			SKSpriteNode *missaile = [SKSpriteNode spriteNodeWithTexture:_textureMissile];
			missaile.position = CGPointMake(spaceship_pt.x, spaceship_pt.y);
			missaile.name = kMissileName;
			[self addChild:missaile];
			//物理シミュレーション
			missaile.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:missaile.size];
			//宇宙船の向きにミサイル発射
			missaile.zRotation = radian;
			CGFloat	x = sin(radian);
			CGFloat	y = cos(radian);
			missaile.physicsBody.velocity = CGVectorMake(-(400*x), (400*y));	//ベクトル
			//接触設定
			missaile.physicsBody.categoryBitMask = missileCategory;		//カテゴリー（ミサイル）
			missaile.physicsBody.contactTestBitMask = meteorCategory;	//ヒットテストするオブジェクト（隕石）
			missaile.physicsBody.collisionBitMask = meteorCategory;		//接触できるオブジェクト（隕石）
			
			//パーティクル
			NSString *path =
				[[NSBundle mainBundle] pathForResource:@"Spark" ofType:@"sks"];
			SKEmitterNode	*fireSpark =
				[NSKeyedUnarchiver unarchiveObjectWithFile:path];
			fireSpark.position = CGPointMake((missaile.size.width/2)-7,
											-(missaile.size.height/2));
			//パーティクルの調整。ロケット噴射のように見せる
			fireSpark.particleLifetime = 0.1;
			fireSpark.numParticlesToEmit = 50;
			fireSpark.particleBirthRate = 200;
			fireSpark.emissionAngle = -(M_PI/2);
			fireSpark.emissionAngleRange = 0;
			fireSpark.particlePositionRange = CGVectorMake(0, 0);
			//ロケットに配置
			[missaile addChild:fireSpark];
			 
		}];
	}
}


//隕石のランダム作成
- (void) addMeteor
{
	if(_gameOver){
		return;
	}
	SKSpriteNode *meteor = [SKSpriteNode spriteNodeWithTexture:_textureMeteor];
	meteor.position = CGPointMake(skRand(40, 240), self.size.height);
	meteor.name = kMeteorName;
	//物理シミュレーション
	meteor.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:meteor.size.width/2];
	[self addChild:meteor];
	//接触設定
	meteor.physicsBody.categoryBitMask = meteorCategory;		//カテゴリー（隕石）
	meteor.physicsBody.contactTestBitMask = spaceshipCategory|earthCategory;//ヒットテストするオブジェクト（宇宙船／ミサイル）
	meteor.physicsBody.collisionBitMask = spaceshipCategory|earthCategory;	//接触できるオブジェクト（宇宙船／ミサイル）
	
	//下方向に回転させて発射
	meteor.physicsBody.velocity = CGVectorMake(skRand(-25, 25), -(skRand(50, 60)));
	[meteor.physicsBody applyTorque:0.04];//回転
	
	 //隕石のパーティクル
	 NSString *path = [[NSBundle mainBundle] pathForResource:@"Spark" ofType:@"sks"];
	 SKEmitterNode	*fireSpark = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
	 fireSpark.position = CGPointMake(0, 0);
	 fireSpark.particleLifetime = 0.3;
	 fireSpark.particleBirthRate = 500;
	 fireSpark.emissionAngle = (M_PI/2);
	 fireSpark.emissionAngleRange = 0;
	 fireSpark.particlePositionRange = CGVectorMake(10, 10);
	 fireSpark.particleAlpha = 0.4;
	 fireSpark.particleAlphaRange = 0.0;
	 fireSpark.particleAlphaSpeed = -0.3;
	 //パーティクルを隕石に配置
	 [meteor addChild:fireSpark];
	 fireSpark.targetNode = self;
}

static inline CGFloat skRand(CGFloat low, CGFloat high)
{
	return skRandf() * (high - low) + low;
}
static inline CGFloat skRandf()
{
	return rand() / (CGFloat) RAND_MAX;
}



//削除
-(void)didSimulatePhysics
{
	[self enumerateChildNodesWithName:kMeteorName usingBlock:^(SKNode *node, BOOL *stop) {
        if (node.position.y < 0 || node.position.x < 0 || node.position.x > 320)
            [node removeFromParent];
	}];
	[self enumerateChildNodesWithName:kMissileName usingBlock:^(SKNode *node, BOOL *stop) {
        if (node.position.y > self.frame.size.height || node.position.y < 0 || node.position.x < 0 || node.position.x > 320)
            [node removeFromParent];
	}];
	
}


//スコア更新
-(void)setScore:(int)score
{
	_score = score;
	//ラベル更新
	//名前から宇宙船を検索
	SKLabelNode*	scoreNode;
	scoreNode = (SKLabelNode*)[self childNodeWithName:kScoreName];
	scoreNode.text = [NSString stringWithFormat:@"%d", _score];
}

//隕石落下数
-(void)setFallenNumber:(int)fallenNumber
{
	_fallenNumber = fallenNumber;
	if(_fallenNumber < 0)
		_fallenNumber = 0;
	//名前からラベルを検索
	SKLabelNode*	fallenNumNode = (SKLabelNode*)[self childNodeWithName:kFallenName];
	//ラベル更新
	fallenNumNode.text = [NSString stringWithFormat:@"%d", _fallenNumber];
	
	if(_fallenNumber <= 0){
		[self showGameOver];	//ゲームオーバー
	}
}




//ゲームオーバー
-(void) showGameOver
{
	if(_gameOver==NO){
		_gameOver = YES;	//ゲームオーバーフラグ
		SKLabelNode *gameOverLabel = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		gameOverLabel.text = @"GAME OVER";
		gameOverLabel.fontSize = 40;
		gameOverLabel.position = CGPointMake(CGRectGetMidX(self.frame),
											 CGRectGetMidY(self.frame)+50);
		[self addChild:gameOverLabel];
		
		//点滅アクション
		SKLabelNode *pleaseTouch = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		pleaseTouch.text = @"Please, touch the screen";
		pleaseTouch.fontSize = 20;
		pleaseTouch.position = CGPointMake(CGRectGetMidX(self.frame),80);
		[self addChild:pleaseTouch];
		NSArray*	actions = @[[SKAction fadeAlphaTo:0.0 duration:0.75],
								[SKAction fadeAlphaTo:1.0 duration:0.75]];
		SKAction*	action = [SKAction repeatActionForever:[SKAction sequence:actions]];
		[pleaseTouch runAction:action];
	}
}

//ミサイル発射
-(void)missaileShooting:(CGFloat)radian
{
	//名前から宇宙船を検索
	SKNode*		spaceship = [self childNodeWithName:kSpaceshipName];
	//宇宙船の位置
	CGPoint		spaceship_pt = spaceship.position;
	//回転角度から回転速度を求める
	CGFloat		 diff = fabsf(spaceship.zRotation-radian);
	NSTimeInterval	time = diff * 0.3;
	
	//宇宙船回頭
	_isRotating = YES;	//回転中フラグON
	SKAction*	rotate = [SKAction rotateToAngle:radian duration:time];
	[spaceship runAction:rotate completion:^{
		//宇宙船回頭後、ミサイル発射
		_isRotating = NO;	//回転中フラグOFF
		//ミサイル作成
		SKSpriteNode *missaile = [SKSpriteNode spriteNodeWithTexture:_textureMissile];
		missaile.position = CGPointMake(spaceship_pt.x, spaceship_pt.y);
		missaile.name = kMissileName;
		[self addChild:missaile];
		missaile.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:missaile.size];
		//宇宙船の向きにミサイル発射
		missaile.zRotation = radian;
		CGFloat	x = sin(radian);
		CGFloat	y = cos(radian);
		missaile.physicsBody.velocity = CGVectorMake(-(400*x), (400*y));	//ベクトル
		
		//接触設定
		missaile.physicsBody.categoryBitMask = missileCategory;		//カテゴリー（ミサイル）
		missaile.physicsBody.contactTestBitMask = meteorCategory;	//ヒットテストするオブジェクト（隕石）
		missaile.physicsBody.collisionBitMask = meteorCategory;		//接触できるオブジェクト（隕石）
		
		//パーティクル
		//スパーク
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Spark" ofType:@"sks"];
		SKEmitterNode	*fireSpark = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
		fireSpark.position = CGPointMake((missaile.size.width/2)-7, -(missaile.size.height/2));
		//パーティクルの調整。ロケット噴射のように見せる
		fireSpark.particleLifetime = 0.1;
		fireSpark.numParticlesToEmit = 50;
		fireSpark.particleBirthRate = 200;
		fireSpark.emissionAngle = -(M_PI/2);
		fireSpark.emissionAngleRange = 0;
		fireSpark.particlePositionRange = CGVectorMake(0, 0);
		//ロケットに配置
		[missaile addChild:fireSpark];
	}];
}


//炎パーティクル作成
-(void)makeFireParticle:(CGPoint)point
{
	if(_particleFire==nil){
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Fire" ofType:@"sks"];
		_particleFire = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
		_particleFire.numParticlesToEmit = 50;
		[self addChild:_particleFire];
	}
	else{
		[_particleFire resetSimulation];
	}
	_particleFire.position = point;
}
//スパークパーティクル作成
-(void)makeSparkParticle:(CGPoint)point
{
	if(_particleSpark==nil){
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Spark" ofType:@"sks"];
		_particleSpark = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
		_particleSpark.numParticlesToEmit = 50;
		[self addChild:_particleSpark];
	}
	else{
		[_particleSpark resetSimulation];
	}
	_particleSpark.position = point;
}
//ボムパーティクル作成
-(void)makeBomParticle:(CGPoint)point
{
	if(_particleBom==nil){
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Bom" ofType:@"sks"];
		_particleBom = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
		_particleBom.numParticlesToEmit = 350;
		[self addChild:_particleBom];
	}
	else{
		[_particleBom resetSimulation];
	}
	_particleBom.position = point;
}
//スモークパーティクル作成
-(void)makeSmokeParticle:(CGPoint)point
{
	if(_particleSmoke==nil){
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Smoke" ofType:@"sks"];
		_particleSmoke = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
		_particleSmoke.numParticlesToEmit = 100;
		[self addChild:_particleSmoke];
	}
	else{
		[_particleBom resetSimulation];
	}
	_particleSmoke.position = point;
}



#pragma mark - SKPhysicsContactDelegate

//衝突開始
- (void)didBeginContact:(SKPhysicsContact *)contact
{
	NSString*	bodyNameA = contact.bodyA.node.name;
	//隕石が地球に落下！
	if([bodyNameA isEqualToString:kEarthName]){
		//落下パーティクル作成
		[self makeBomParticle:contact.contactPoint];
		[self makeSmokeParticle:contact.contactPoint];
		self.fallenNumber--;	//落下数更新
	}
	//隕石が宇宙船に衝突！
	if([bodyNameA isEqualToString:kSpaceshipName]){
		//炎パーティクル作成
		[self makeFireParticle:contact.contactPoint];
		//スパークパーティクル作成
		[self makeSparkParticle:contact.contactPoint];
		//宇宙船を削除
		[contact.bodyA.node removeFromParent];
		//ゲームオーバー
		[self showGameOver];
	}
	//隕石とミサイルが衝突！
	else if([bodyNameA isEqualToString:kMissileName]){
		//炎パーティクル作成
		[self makeFireParticle:contact.contactPoint];
		//スパークパーティクル作成
		[self makeSparkParticle:contact.contactPoint];
		//ミサイルを削除
		[contact.bodyA.node removeFromParent];
		self.score += 10;	//スコア更新
	}
	//隕石を削除
	[contact.bodyB.node removeFromParent];
}

//衝突終了
- (void)didEndContact:(SKPhysicsContact *)contact
{
	
}


@end
