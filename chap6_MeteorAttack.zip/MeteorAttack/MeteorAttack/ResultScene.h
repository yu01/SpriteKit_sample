//
//  ResultScene.h
//

#import <SpriteKit/SpriteKit.h>

@interface ResultScene : SKScene
@property	(weak, nonatomic)	id		delegate;

-(void)setScore:(int)score HiScore:(int)hiScore;

@end
