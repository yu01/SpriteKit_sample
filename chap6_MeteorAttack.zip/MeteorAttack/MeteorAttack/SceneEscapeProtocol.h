//
//  SceneEscapeProtocol.h
//  MeteorAttack
//

@protocol SceneEscapeProtocol <NSObject>
-(void)sceneEscape:(SKScene *)scene;
@end

