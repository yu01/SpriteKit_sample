//
//  TitleScene.m
//

#import "TitleScene.h"
#import "SceneEscapeProtocol.h"

@implementation TitleScene

-(id)initWithSize:(CGSize)size
{
    if (self = [super initWithSize:size]) {
		//背景
		SKSpriteNode* space = [SKSpriteNode spriteNodeWithImageNamed:@"TitleBack"];
		space.position = CGPointMake(self.size.width/2, self.size.height/2);
		space.name = @"back";
		[self addChild:space];
		
		//ハイスコア
		//タイトル
		SKLabelNode *scoreTitleNode = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		scoreTitleNode.fontSize = 20;
		scoreTitleNode.text = @"HI-SCORE";
		[self addChild:scoreTitleNode];
		scoreTitleNode.position = CGPointMake((scoreTitleNode.frame.size.width/2)+20, self.frame.size.height-30);
		//得点
		SKLabelNode*	hiScoreNode = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		hiScoreNode.fontSize = 20;
		[self addChild:hiScoreNode];
		hiScoreNode.position = CGPointMake(CGRectGetMidX(self.frame), self.frame.size.height-30);
		//ハイスコアをNSUserDefaultsから読み込む
		NSUserDefaults* userdef = [NSUserDefaults standardUserDefaults];
		int	hiScore = (int)[userdef integerForKey:@"hi_score"];
		hiScoreNode.text = [NSString stringWithFormat:@"%d", hiScore];
		
		
		//点滅アクション
		SKLabelNode *pleaseTouch = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		pleaseTouch.text = @"GAME START";
		pleaseTouch.fontSize = 20;
		pleaseTouch.position = CGPointMake(CGRectGetMidX(self.frame),80);
		[self addChild:pleaseTouch];
		NSArray*	actions = @[[SKAction fadeAlphaTo:0.0 duration:0.75],
								[SKAction fadeAlphaTo:1.0 duration:0.75]];
		SKAction*	action = [SKAction repeatActionForever:[SKAction sequence:actions]];
		[pleaseTouch runAction:action];
		
    }
    return self;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//タッチ通知
	if([_delegate respondsToSelector:@selector(sceneEscape:)]){
		[_delegate sceneEscape:self];
	}
}

@end
