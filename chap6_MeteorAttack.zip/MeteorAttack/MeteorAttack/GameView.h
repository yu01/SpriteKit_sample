//
//  GameView.h
//

#import <SpriteKit/SpriteKit.h>

@interface GameView : SKView

-(void) setUpGameView;

-(void) switchingTitleScene;
-(void) switchingGameScene;
-(void) switchingResultScene;

@end
