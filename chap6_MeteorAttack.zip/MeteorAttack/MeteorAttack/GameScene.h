//
//  GameScene.h
//

#import <SpriteKit/SpriteKit.h>

//オブジェクト名
#define		kMissileName		@"Missile"		//ミサイル
#define		kSpaceshipName		@"Spaceship"	//宇宙船
#define		kMeteorName			@"Meteor"		//隕石
#define		kEarthName			@"Earth"		//地球
#define		kBackName			@"Back"			//背景
#define		kScoreName			@"Score"		//スコア
#define		kFallenName			@"Fallen"		//落下数

#define		kLevelName			@"Level"		//レベル

//カテゴリビットマスク
static const uint32_t missileCategory	=  0x1 << 0;	//ミサイル
static const uint32_t meteorCategory	=  0x1 << 1;	//隕石
static const uint32_t earthCategory		=  0x1 << 2;	//地球
static const uint32_t spaceshipCategory	=  0x1 << 3;	//宇宙船

@interface GameScene : SKScene <SKPhysicsContactDelegate>
@property	(weak, nonatomic)	id				delegate;
@property	(assign, nonatomic)	int				score;			//スコア
@property	(assign, nonatomic)	int				fallenNumber;	//隕石衝突数
@end


