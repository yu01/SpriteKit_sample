//
//  TitleScene.h
//

#import <SpriteKit/SpriteKit.h>

@interface TitleScene : SKScene
@property	(weak, nonatomic)	id		delegate;
@end


