//
//  CharactorNode.h
//

#import <SpriteKit/SpriteKit.h>

typedef enum {
	kCharaDirectionDown,		// 下移動
	kCharaDirectionLeft,		// 左移動
	kCharaDirectionUp,			// 上移動
	kCharaDirectionRight,		// 右移動
} CharaDirection;

typedef void(^ShootFinishBlocks)(CGFloat angle);

@interface CharactorNode : SKSpriteNode
@property	(nonatomic, assign)	CGFloat			angle;			//向いている角度（ラジアン）
@property	(nonatomic, assign)	CGFloat			velocity;		//移動している速度
@property	(nonatomic, assign)	CGFloat			animeSpeed;		//アニメーション１コマのスピード
@property	(nonatomic, assign)	CGFloat			hp;				//キャラクターHP
@property	(nonatomic, assign)	CharaDirection	charaDirection;	//移動方向
@property	(nonatomic, assign)	BOOL			inTextureAnime;	//テクスチャアニメ中フラグ
@property	(nonatomic, assign)	BOOL			inShootAnime;	//攻撃中フラグ
@property	(nonatomic, assign)	BOOL			isGetDamage;	//ダメージ中フラグ
@property	(nonatomic, strong) SKTextureAtlas*	textureAtlas;	//テクスチャアトラス

+(CharactorNode *)charactorNodeWith:(NSString*)name TextureAtlas:(SKTextureAtlas*)textureAtlas;
+(CharaDirection)angleToDirection:(CGFloat)direction;
-(void)setAngle:(CGFloat)angle Velocity:(CGFloat)velocity;
-(void)stop;
-(void)update;
-(void)shoot:(ShootFinishBlocks)response;
@end
