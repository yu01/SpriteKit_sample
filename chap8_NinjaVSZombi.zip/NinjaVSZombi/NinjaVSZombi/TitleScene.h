//
//  TitleScene.h
//  SPKitGameDemo
//

#import <SpriteKit/SpriteKit.h>

@interface TitleScene : SKScene
@property	(weak, nonatomic)	id		delegate;
@end


