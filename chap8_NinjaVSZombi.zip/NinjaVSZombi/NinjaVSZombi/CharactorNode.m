//
//  CharactorNode.m
//

#import "CharactorNode.h"

@implementation CharactorNode

+(CharactorNode *)charactorNodeWith:(NSString*)name
					   TextureAtlas:(SKTextureAtlas*)textureAtlas
{
	//プレイヤーノード
	NSString*	texname = [NSString stringWithFormat:@"%@_down1",name];
	SKTexture*	texture = [textureAtlas textureNamed:texname];
	CharactorNode*	charaNode = [CharactorNode spriteNodeWithTexture:texture];
	charaNode.textureAtlas = textureAtlas;
	charaNode.name = name;
	charaNode.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:charaNode.size.width/2];
	charaNode.physicsBody.affectedByGravity = NO;	//重力適用なし
	charaNode.physicsBody.allowsRotation = NO;		//衝突による角度変更なし
	charaNode.physicsBody.linearDamping = 1.0;		//空気抵抗
	[charaNode setAngle:M_PI Velocity:0];
	charaNode.animeSpeed = 0.1;
	return charaNode;
}

+(CharaDirection)angleToDirection:(CGFloat)direction
{
	CharaDirection	res;
	//計算しやすいようにラジアンから弧度法に直す
	CGFloat r = direction*180 / M_PI;
	if(r >= -135 && -45 > r){
		res = kCharaDirectionRight;	//右
	}else if(r >= -45 && 45 > r){
		res = kCharaDirectionUp;	//上
	}else if(r >= 45 && 135 > r){
		res = kCharaDirectionLeft;	//左
	}else{
		res = kCharaDirectionDown;	//下
	}
	return res;
}


-(void)setAngle:(CGFloat)angle Velocity:(CGFloat)velocity
{
	if(self.inShootAnime){
		return;
	}
	self.angle = angle;
	if(velocity==0){
		[self stop];	//停止
	}else{
		CharaDirection dirction = [CharactorNode angleToDirection:_angle];
		if(self.charaDirection!=dirction || (_velocity==0 && velocity!=0 )){
			self.charaDirection = dirction;
		}
	}
	self.velocity = velocity;
}

-(void)stop
{
	if(self.inShootAnime){
		return;
	}
	_velocity = 0;
	NSString*	direction;
	if(_charaDirection==kCharaDirectionRight){
		direction = @"right";	//右
	}
	else if(_charaDirection==kCharaDirectionUp){
		direction = @"up";		//上
	}
	else if(_charaDirection==kCharaDirectionLeft){
		direction = @"left";	//左
	}
	else {
		direction = @"down";	//下
	}
	//停止
	self.inTextureAnime = NO;
	[self removeActionForKey:@"charaMove"];
	
	NSString*	texname = [NSString stringWithFormat:@"%@_%@1",self.name,direction];
	SKTexture*	texture = [self.textureAtlas textureNamed:texname];
	self.texture = texture;
	
}

-(void)update
{
	if(self.inShootAnime){
		return;
	}
	//角度からベクトルを求める
	CGFloat	x = sin(_angle) * _velocity;
	CGFloat	y = cos(_angle) * _velocity;
	//ベクトルを加える
	self.physicsBody.velocity = CGVectorMake(-x, y);
	
}


// 動作設定
-(void) setCharaDirection:(CharaDirection)charaDirection
{
	//テクスチャーアニメーション停止中か、異なる設定の場合
	if(self.inTextureAnime==NO || _charaDirection!=charaDirection){
		_charaDirection = charaDirection;
		SKAction*	action = nil;
		NSString*	direction;
		if(charaDirection==kCharaDirectionRight){
			direction = @"right";	//右
		}
		else if(charaDirection==kCharaDirectionUp){
			direction = @"up";		//上
		}
		else if(charaDirection==kCharaDirectionLeft){
			direction = @"left";	//左
		}
		else {
			direction = @"down";	//下
		}
		NSArray* ary = @[
						 [_textureAtlas textureNamed:[NSString stringWithFormat:@"%@_%@1",self.name,direction]],
						 [_textureAtlas textureNamed:[NSString stringWithFormat:@"%@_%@2",self.name,direction]],
						 [_textureAtlas textureNamed:[NSString stringWithFormat:@"%@_%@3",self.name,direction]]];
		action = [SKAction animateWithTextures:ary timePerFrame:_animeSpeed resize:YES restore:YES];
		
		//NSLog(@"%@ %d", name, charaDirection);
		
		//テクスチャアニメーション設定
		self.inTextureAnime = YES;
		[self runAction:[SKAction repeatActionForever:action] withKey:@"charaMove"];
	}
}

-(void)shoot:(ShootFinishBlocks)response
{
	if(self.inShootAnime){
		return;
	}
	[self stop];
	
	self.inShootAnime = YES;
	CGFloat	retAngle = 0;
	NSString*	direction;
	if(_charaDirection==kCharaDirectionRight){
		direction = @"right";	//右
		retAngle = -(M_PI/2);
	}
	else if(_charaDirection==kCharaDirectionUp){
		direction = @"up";		//上
		retAngle = 0;
	}
	else if(_charaDirection==kCharaDirectionLeft){
		direction = @"left";	//左
		retAngle = M_PI/2;
	}
	else {
		direction = @"down";	//下
		retAngle = M_PI;
	}
	
	NSArray* ary = @[
					 [_textureAtlas textureNamed:[NSString stringWithFormat:@"%@_%@1",self.name,direction]],
					 [_textureAtlas textureNamed:[NSString stringWithFormat:@"%@_%@4",self.name,direction]],
					 [_textureAtlas textureNamed:[NSString stringWithFormat:@"%@_%@5",self.name,direction]]];
	SKAction* action = [SKAction animateWithTextures:ary timePerFrame:0.1 resize:YES restore:YES];
	[self runAction:action completion:^{
		self.inShootAnime = NO;
		if(response){
			response(retAngle);
		}
	}];
}

-(void)setHp:(CGFloat)hp
{
	_hp = hp;
	if(_hp < 0)
		_hp = 0;
}


//ダメージフラグ
-(void)setIsGetDamage:(BOOL)isGetDamage
{
	_isGetDamage = isGetDamage;
	NSString*	direction;
	if(_charaDirection==kCharaDirectionRight){
		direction = @"right";	//右
	}
	else if(_charaDirection==kCharaDirectionUp){
		direction = @"up";		//上
	}
	else if(_charaDirection==kCharaDirectionLeft){
		direction = @"left";	//左
	}
	else {
		direction = @"down";	//下
	}
	if(_isGetDamage){
		_velocity = 0;
		self.inTextureAnime = NO;
		[self removeActionForKey:@"charaMove"];
		self.texture = [_textureAtlas textureNamed:[NSString
													stringWithFormat:@"%@_%@6",
													self.name,direction]];
		
		[self runAction:[SKAction waitForDuration:0.5] completion:^{
			self.isGetDamage = NO;//一定時間でOFFにする
		}];
	}else{
		self.texture = [_textureAtlas textureNamed:[NSString
													stringWithFormat:@"%@_%@1",
													self.name,direction]];
	}
}

@end
