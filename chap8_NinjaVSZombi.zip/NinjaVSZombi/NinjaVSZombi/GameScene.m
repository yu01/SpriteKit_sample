//
//  GameScene.m
//  SPKitGameDemo
//

#import "GameScene.h"
#import "GameView.h"

@implementation GameScene{
	
	CGPoint			_touchPoint;
}

-(id)initWithSize:(CGSize)size {
    if (self = [super initWithSize:size]) {
		
		//オートスクロールのベースノード
		self.anchorPoint = CGPointMake (0.5,0.5);
		self.baseNode = [SKNode node];
		[self addChild:self.baseNode];
		
		//マップの全体サイズ
		self.mapSize = CGSizeMake(320*3, 320*3);
		
		//マップ表示
		SKTexture*	texture = [SKTexture textureWithImageNamed:@"back"];
		for (int y=0; y < 3; y++) {
			for (int x=0; x < 3; x++) {
				//背景ノード
				SKSpriteNode* node;
				node = [SKSpriteNode spriteNodeWithTexture:texture];
				node.position = CGPointMake((node.size.width / 2)+(x * 320),
											(node.size.height / 2)+(y * 320));
				[self.baseNode addChild:node];
			}
		}
		
		
		// プレイヤーノード
		SKTextureAtlas* playerAtlas = [SKTextureAtlas atlasNamed:@"ninja"];
		self.playerNode = [CharactorNode charactorNodeWith:kPlayerName
											  TextureAtlas:playerAtlas];
		self.playerNode.hp = 100;
		[self.baseNode addChild:self.playerNode];
		self.playerNode.position = CGPointMake(480, 480);
		self.playerNode.physicsBody.categoryBitMask = playerCategory;
		self.playerNode.physicsBody.collisionBitMask = enemyCategory|frameCategory;
		
		
		//マップの外枠フレーム当たり
		SKNode*	frameNode = [SKNode node];
		[self.baseNode addChild:frameNode];
		frameNode.position = CGPointMake((self.mapSize.width/2), (self.mapSize.height/2));
		frameNode.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:CGRectMake(-(self.mapSize.width/2),
																				   -(self.mapSize.height/2),
																				   self.mapSize.width,
																				   self.mapSize.height)];
		frameNode.physicsBody.categoryBitMask = frameCategory;
		frameNode.physicsBody.collisionBitMask = playerCategory;
		
		//接触デリゲート
		self.physicsWorld.contactDelegate = self;
		
		// 敵ノード
		static CGPoint	enemyPos[10] = {
			{500, 700},{620, 710},{540, 740},{620, 670},{440, 760},
			{440, 370},{300, 230},{400, 240},{820, 670},{330, 560},
		};
		SKTextureAtlas* enemyAtlas = [SKTextureAtlas atlasNamed:@"zombi"];
		for (int i=0; i < 10; i++) {
			CharactorNode*	enemy = [CharactorNode charactorNodeWith:kEnemyName
													   TextureAtlas:enemyAtlas];
			[self.baseNode addChild:enemy];
			enemy.hp = 30;
			enemy.position = enemyPos[i];
			enemy.physicsBody.categoryBitMask = enemyCategory;
			enemy.physicsBody.collisionBitMask = playerCategory|enemyCategory|frameCategory;
			enemy.physicsBody.contactTestBitMask = playerCategory;
		}
    }
    return self;
}

-(void)didSimulatePhysics
{
	[self.playerNode update];
	
	//プレイヤーの位置に合わせてオートスクロール
	//シーン上でのレーシングカーの座標を道路ノードからの位置に変換
	CGPoint pt = [self convertPoint:self.playerNode.position fromNode:self.baseNode];
	
	//シーン上でベースノードの位置を変更する
	CGFloat	mv_x, mv_y;
	mv_x = self.baseNode.position.x - pt.x;
	mv_y = self.baseNode.position.y - pt.y;
	self.baseNode.position = CGPointMake(mv_x, mv_y);
	
	//手裏剣
	[self.baseNode enumerateChildNodesWithName:kWeponName usingBlock:^(SKNode *node, BOOL *stop) {
		CGPoint pt = node.position;
		if(pt.x < 0 || pt.y < 0 || pt.x > _mapSize.width || pt.y > _mapSize.height){
			//マップ外に出た手裏剣を削除
			[node removeFromParent];
		}
	}];
	
	
	//敵AI
	[self.baseNode enumerateChildNodesWithName:kEnemyName usingBlock:^(SKNode *node, BOOL *stop) {
		CharactorNode* enemy = (CharactorNode*)node;
		if(enemy.isGetDamage==NO){
			CGPoint		dogPos = self.playerNode.position;
			CGPoint		enemyPos = enemy.position;
			//距離判定
			double	x = fabs(enemyPos.x - dogPos.x);
			double	y = fabs(enemyPos.y - dogPos.y);
			CGFloat	length = sqrt((x*x)+(y*y)) * 2;
			if(length < 700){
				//プレイヤーの方向に移動する
				CGFloat	angle = -(atan2f(dogPos.x-enemyPos.x, dogPos.y-enemyPos.y));
				if(enemy.velocity==0){
					enemy.velocity = 30;
					[enemy setAngle:angle Velocity:enemy.velocity];
				}else{
					CharaDirection dirction = [CharactorNode angleToDirection:angle];
					enemy.charaDirection = dirction;
					enemy.angle = angle;
				}
			}
			else if(enemy.velocity!=0) {
				[enemy stop];
			}
			[enemy update];
		}
	}];
}



//タッチダウン
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//タッチダウンした位置を記録
	UITouch *touch = [touches anyObject];
	_touchPoint = [touch locationInNode:self];
	NSUInteger  tapNum = [touch tapCount];
	if(tapNum > 1){
		//手裏剣を投げる
		[self.playerNode shoot:^(CGFloat angle){
			SKSpriteNode*	wepon = [SKSpriteNode spriteNodeWithImageNamed:@"wepon"];
			wepon.name = kWeponName;
			wepon.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:wepon.size.width/2];
			wepon.physicsBody.affectedByGravity = NO;	//重力適用なし
			[self.baseNode addChild:wepon];
			wepon.position = self.playerNode.position;
			wepon.physicsBody.categoryBitMask = weponCategory;
			wepon.physicsBody.collisionBitMask = enemyCategory;
			wepon.physicsBody.contactTestBitMask = enemyCategory;
			wepon.zRotation = angle;	//手裏剣を回転させる
			CGFloat	impulse = 5.5;		//手裏剣の飛ぶ速さ
			CGFloat	x = sin(angle) * impulse;
			CGFloat	y = cos(angle) * impulse;
			[wepon.physicsBody applyImpulse:CGVectorMake(-x, y)];
		}];
	}
}

//タッチムーブ
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(self.playerNode.isGetDamage==NO ){
		//タッチダウンした位置を得る
		UITouch *touch = [touches anyObject];
		CGPoint	location = [touch locationInNode:self];
		
		//タッチダウンした位置からの距離を求め、それを速度とする
		double	x = fabs(_touchPoint.x-location.x);
		double	y = fabs(_touchPoint.y-location.y);
		CGFloat	velocity = sqrt((x*x)+(y*y)) * 2;
		if(velocity < 30){
			velocity = 30;		//微速で進む
		}else if(velocity > 100){
			velocity = 100;		//最高速固定
		}
		
		//タッチダウンした位置からプレイヤーの進行方向を求める
		CGFloat	angle = -(atan2f(location.x-_touchPoint.x, location.y-_touchPoint.y));
		
		//プレイヤーキャラにアングルと速度を設定
		[self.playerNode setAngle:angle Velocity:velocity];
	}
}
//タッチアップ
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	[self.playerNode stop];
}



- (void)didBeginContact:(SKPhysicsContact *)contact
{
	NSString*	bodyNameA = contact.bodyA.node.name;
	NSString*	bodyNameB = contact.bodyB.node.name;
	NSLog(@"A=%@ B=%@ Impulse=%.3f",bodyNameA, bodyNameB, contact.collisionImpulse);
	
	//手裏剣が敵に当たった
	if(([bodyNameA isEqualToString:kEnemyName]&&[bodyNameB isEqualToString:kWeponName])||
	   ([bodyNameB isEqualToString:kEnemyName]&&[bodyNameA isEqualToString:kWeponName])){
		
		CharactorNode* enemy;
		SKNode*			wepon;
		if([bodyNameB isEqualToString:kWeponName]){
			enemy = (CharactorNode*)contact.bodyA.node;
			wepon = contact.bodyB.node;
		}else{
			enemy = (CharactorNode*)contact.bodyB.node;
			wepon = contact.bodyA.node;
		}
		//敵のHPを減らす
		enemy.hp -= contact.collisionImpulse;
		//敵をノックバックさせる
		enemy.isGetDamage = YES;
		CGFloat	angle = wepon.zRotation;
		CGFloat	x = sin(angle) * (contact.collisionImpulse/3);
		CGFloat	y = cos(angle) * (contact.collisionImpulse/3);
		[enemy.physicsBody applyImpulse:CGVectorMake(-x, y)];
		[wepon removeFromParent];//手裏剣を消す
		//敵死亡
		if(enemy.hp <= 0){
			//敵を透明にして消す
			enemy.physicsBody.collisionBitMask = 0;
			NSArray*	ary = @[
								[SKAction fadeAlphaTo:0 duration:0.25],
								[SKAction removeFromParent]];
			[enemy runAction:[SKAction sequence:ary]];
		}
	}
	
	//敵がプレイヤーに接触
	if(([bodyNameA isEqualToString:kPlayerName] && [bodyNameB isEqualToString:kEnemyName])||
	   ([bodyNameB isEqualToString:kPlayerName] && [bodyNameA isEqualToString:kEnemyName])){
		CharactorNode* enemy;
		if([bodyNameB isEqualToString:kEnemyName]){
			enemy = (CharactorNode*)contact.bodyB.node;
		}else{
			enemy = (CharactorNode*)contact.bodyA.node;
		}
		//敵がプレイヤーを攻撃する
		[enemy shoot:^(CGFloat angle) {
			//プレイヤーのHPを減らす
			self.playerNode.hp -= 10;
			//プレイヤーにダメージパターン
			self.playerNode.isGetDamage = YES;
			//プレイヤー死亡
			if(self.playerNode.hp <= 0){
				//プレイヤーを透明にして消す
				self.playerNode.physicsBody.collisionBitMask = 0;
				NSArray*	ary = @[
									[SKAction fadeAlphaTo:0 duration:0.25],
									[SKAction removeFromParent]];
				[self.playerNode runAction:[SKAction sequence:ary]];
			}
		}];
	}
}


@end
