﻿//
//  GameScene.h
//

#import <SpriteKit/SpriteKit.h>
#import "CharactorNode.h"

//オブジェクト名
#define		kPlayerName				@"ninja"			//プレイヤー
#define		kEnemyName				@"zombi"			//敵
#define		kWeponName				@"wepon"			//手裏剣
//カテゴリビットマスク
static const uint32_t frameCategory		=  0x1 << 0;	//外枠
static const uint32_t playerCategory	=  0x1 << 1;	//プレイヤー
static const uint32_t enemyCategory		=  0x1 << 2;	//敵
static const uint32_t weponCategory		=  0x1 << 3;	//手裏剣

@interface GameScene : SKScene<SKPhysicsContactDelegate>
@property	(weak, nonatomic)	id				delegate;
@property	(strong, nonatomic)	SKNode*			baseNode;
@property	(assign, nonatomic)	CGSize			mapSize;
@property	(strong, nonatomic)	CharactorNode*	playerNode;

@end
