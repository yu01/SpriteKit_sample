//
//  TitleScene.m
//  SPKitGameDemo
//

#import "TitleScene.h"
#import "GameView.h"

@implementation TitleScene

-(id)initWithSize:(CGSize)size {    
    if (self = [super initWithSize:size]) {
		SKLabelNode *myLabel = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		myLabel.text = @"NINJA vs ZOMBI";
		myLabel.fontSize = 30;
		myLabel.position = CGPointMake(CGRectGetMidX(self.frame),
									   CGRectGetMidY(self.frame));
		[self addChild:myLabel];
		
		//点滅アクション
		SKLabelNode *pleaseTouch = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		pleaseTouch.text = @"GAME START";
		pleaseTouch.fontSize = 20;
		pleaseTouch.position = CGPointMake(CGRectGetMidX(self.frame),80);
		[self addChild:pleaseTouch];
		NSArray*	actions = @[[SKAction fadeAlphaTo:0.0 duration:0.75],
								[SKAction fadeAlphaTo:1.0 duration:0.75]];
		SKAction*	action = [SKAction repeatActionForever:[SKAction sequence:actions]];
		[pleaseTouch runAction:action];
		
		
    }
    return self;
}

-(void)update:(CFTimeInterval)currentTime
{
}

- (void)willMoveFromView:(SKView *)view
{
}

- (void)didMoveToView: (SKView*) view
{
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//タッチ通知
	if([_delegate respondsToSelector:@selector(sceneEscape:)]){
		[_delegate sceneEscape:self];
	}
}


@end
