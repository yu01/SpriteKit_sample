//
//  GameView.h
//  SPKitGameDemo
//

#import <SpriteKit/SpriteKit.h>

@interface GameView : SKView

-(void) setUpGameView;

-(void) switchingTitleScene;
-(void) switchingGameScene;
-(void) switchingResultScene;

@end


@protocol SceneEscapeProtocol <NSObject>
-(void)sceneEscape:(SKScene *)scene;
@end

