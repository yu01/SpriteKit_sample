//
//  ResultScene.m
//  SPKitGameDemo
//

#import "ResultScene.h"
#import "GameView.h"

@implementation ResultScene

-(id)initWithSize:(CGSize)size {
    if (self = [super initWithSize:size]) {
		SKLabelNode *myLabel = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		myLabel.text = [NSString stringWithFormat:@"%@",[self class]];
		myLabel.fontSize = 30;
		myLabel.position = CGPointMake(CGRectGetMidX(self.frame),
									   CGRectGetMidY(self.frame));
		[self addChild:myLabel];
    }
    return self;
}

-(void)update:(CFTimeInterval)currentTime
{
}

- (void)willMoveFromView:(SKView *)view
{
}

- (void)didMoveToView: (SKView*) view
{
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//タッチ通知
	if([_delegate respondsToSelector:@selector(sceneEscape:)]){
		[_delegate sceneEscape:self];
	}
}

@end
