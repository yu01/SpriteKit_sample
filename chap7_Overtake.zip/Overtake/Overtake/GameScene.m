//
//  GameScene.m
//  SPKitGameDemo
//

#import "GameScene.h"
#import "GameView.h"

@implementation GameScene{
	
	CGPoint		_carStartPt;
	
	BOOL		_gameOver;
	BOOL		_acceleON;
	CGPoint		_touchPoint;
	
	CGFloat		_accelete;
	
	SKEmitterNode*	_particleFire;			//炎のパーティクル
	SKEmitterNode*	_particleSpark;			//スパークのパーティクル
	SKEmitterNode*	_particleSmoke;			//スモークのパーティクル
}

-(id)initWithSize:(CGSize)size {
    if (self = [super initWithSize:size]) {
		
		self.anchorPoint = CGPointMake (0.5,0.5);
		
		//=============================================
		//道路
		SKNode*		roadNode = [SKNode node];
		roadNode.name = kRoadName;
		[self addChild:roadNode];
		//表示ノード（１）
		SKSpriteNode* road;
		road = [SKSpriteNode spriteNodeWithImageNamed:@"Road.png"];
		road.name = kRoadViewName;
		[roadNode addChild:road];
		//表示ノード（２）
		road = [SKSpriteNode spriteNodeWithImageNamed:@"Road.png"];
		road.position = CGPointMake(0, road.size.height);
		road.name = kRoadViewName;
		[roadNode addChild:road];
		
		//=============================================
		//左の壁（１）
		SKSpriteNode*	wall;
		wall = [SKSpriteNode spriteNodeWithImageNamed:@"Wall_L.png"];
		wall.name = kWallName;
		[roadNode addChild:wall];
		wall.position = CGPointMake(-((size.width/2))+(wall.size.width/2), 0);
		wall.physicsBody = [SKPhysicsBody
							bodyWithRectangleOfSize:CGSizeMake(wall.size.width,
															   wall.size.height)];
		wall.physicsBody.affectedByGravity = NO;//重力適用なし
		wall.physicsBody.categoryBitMask = wallCategory;
		wall.physicsBody.collisionBitMask = 0;
		//左の壁（２）
		wall = [SKSpriteNode spriteNodeWithImageNamed:@"Wall_L.png"];
		wall.name = kWallName;
		[roadNode addChild:wall];
		wall.position = CGPointMake(-((size.width/2))+(wall.size.width/2), wall.size.height);
		wall.physicsBody = [SKPhysicsBody
							bodyWithRectangleOfSize:CGSizeMake(wall.size.width,
															   wall.size.height)];
		wall.physicsBody.affectedByGravity = NO;//重力適用なし
		wall.physicsBody.categoryBitMask = wallCategory;
		wall.physicsBody.collisionBitMask = 0;
		
		//=============================================
		//右の壁（１）
		wall = [SKSpriteNode spriteNodeWithImageNamed:@"Wall_R.png"];
		wall.name = kWallName;
		[roadNode addChild:wall];
		wall.position = CGPointMake((size.width/2)-(wall.size.width/2), 0);
		wall.physicsBody = [SKPhysicsBody
							bodyWithRectangleOfSize:CGSizeMake(wall.size.width,
															   wall.size.height)];
		wall.physicsBody.affectedByGravity = NO;//重力適用なし
		wall.physicsBody.categoryBitMask = wallCategory;
		wall.physicsBody.collisionBitMask = 0;
		//右の壁（２）
		wall = [SKSpriteNode spriteNodeWithImageNamed:@"Wall_R.png"];
		wall.name = kWallName;
		[roadNode addChild:wall];
		wall.position = CGPointMake((size.width/2)-(wall.size.width/2), wall.size.height);
		wall.physicsBody = [SKPhysicsBody
							bodyWithRectangleOfSize:CGSizeMake(wall.size.width,
															   wall.size.height)];
		wall.physicsBody.affectedByGravity = NO;//重力適用なし
		wall.physicsBody.categoryBitMask = wallCategory;
		wall.physicsBody.collisionBitMask = 0;
		
		
		//=============================================
		//プレイヤーカー
		SKSpriteNode*	playerCar = [SKSpriteNode
									  spriteNodeWithImageNamed:@"PlayerCar.png"];
		playerCar.name = kPlayerCarName;
		[roadNode addChild:playerCar];
		playerCar.position = CGPointMake(0, -100);
		_carStartPt = playerCar.position;//初期位置を記録
		playerCar.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:playerCar.size];
		playerCar.physicsBody.affectedByGravity = NO;//重力適用なし
		playerCar.physicsBody.allowsRotation = NO;	//衝突による角度変更なし
		//接触設定
		//カテゴリー（プレイヤーカー）
		playerCar.physicsBody.categoryBitMask = playerCarCategory;
		//接触できるオブジェクト（壁／その他の車）
		playerCar.physicsBody.collisionBitMask = wallCategory|otherCarCategory;
		//ヒットテストするオブジェクト（壁／その他の車）
		playerCar.physicsBody.contactTestBitMask = wallCategory|otherCarCategory;
		
		
		//=============================================
		//車を一定間隔でランダムに作る
		SKAction *makeMeteors = [SKAction sequence:
						@[[SKAction performSelector:@selector(addOtherCar) onTarget:self],
						  [SKAction waitForDuration:1.5 withRange:1.0]]];
		[self runAction: [SKAction repeatActionForever:makeMeteors]];
		
		//=============================================
		//走行距離
		SKLabelNode *scoreTitleNode = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		scoreTitleNode.fontSize = 20;
		scoreTitleNode.text = @"Distance";
		[self addChild:scoreTitleNode];
		scoreTitleNode.position = CGPointMake(((scoreTitleNode.frame.size.width/2)+60)-(size.width/2),
											  (self.frame.size.height)/2-30);
		SKLabelNode*	scoreNode = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		scoreNode.name = kDistLabelName;
		scoreNode.fontSize = 20;
		[self addChild:scoreNode];
		scoreNode.position = CGPointMake(50, (self.frame.size.height)/2-30);
		
		//接触デリゲート
		self.physicsWorld.contactDelegate = self;
    }
    return self;
}


//タッチダウン
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(_gameOver){
		//タッチ通知
		if([_delegate respondsToSelector:@selector(sceneEscape:)]){
			[_delegate sceneEscape:self];
		}
	}
	else{
		//タッチダウンした位置を記録してフラグを立てる
		UITouch *touch = [touches anyObject];
		_touchPoint = [touch locationInNode:self];
		_acceleON = YES;
	}
}
//タッチムーブ
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(_gameOver==NO ){
		//タッチダウンした位置からプレイヤーカーの更新角度を求める
		UITouch *touch = [touches anyObject];
		CGPoint	location = [touch locationInNode:self];
		CGFloat	len = fabs(_touchPoint.x-location.x);
		CGFloat	factor = (len/80)>1.0?1.0:(len/80);
		CGFloat	angle = 0;
		//最大２５度回転
		if(_touchPoint.x-location.x > 0){
			angle = (M_PI/180)*25*factor;//左
		}else{
			angle = -((M_PI/180)*25*factor);//右
		}
		//プレイヤーカーを検索
		SKNode*			road = [self childNodeWithName:kRoadName];
		SKSpriteNode*	playerCar =
				(SKSpriteNode*)[road childNodeWithName:kPlayerCarName];
		playerCar.zRotation = angle;
	}
}
//タッチアップ
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	//フラグを下ろす
	_acceleON = NO;
}



-(void)didSimulatePhysics
{
	//プレイヤーカーを検索
	SKNode*			road = [self childNodeWithName:kRoadName];
	SKSpriteNode*	playerCar = (SKSpriteNode*)[road childNodeWithName:kPlayerCarName];
	//プレイヤーカーの回転角からベクトルを求める
	CGFloat	x = sin(playerCar.zRotation);
	CGFloat	y = cos(playerCar.zRotation);
	if(_acceleON){
		//加速
		_accelete += 10;
		if(_accelete > 500)
			_accelete = 500;//最高速度
	}
	else{
		//減速
		_accelete -= 10;
		if(_accelete < 0)
			_accelete = 0;
	}
	//ベクトルを加える
	playerCar.physicsBody.velocity = CGVectorMake(-(_accelete*x), (_accelete*y));
	
	
	//プレイヤーカーの位置に合わせてオートスクロール
	//シーン上でのレーシングカーの座標を道路ノードからの位置に変換
	CGPoint pt = [self convertPoint:playerCar.position fromNode:road];
	//シーン上で道路ノードの位置を変更する
	road.position = CGPointMake(0, road.position.y-pt.y-100);
	
	
	CGFloat	h = self.size.height;
	//表示用道路入れ替え
	[road enumerateChildNodesWithName:kRoadViewName usingBlock:^(SKNode *node, BOOL *stop) {
		CGPoint pt = [road convertPoint:node.position toNode:self];
		if(pt.y < -(h)){
			node.position = CGPointMake(0, node.position.y+(h*2));
		}
	}];
	//壁入れ替え
	[road enumerateChildNodesWithName:kWallName usingBlock:^(SKNode *node, BOOL *stop) {
		CGPoint pt = [road convertPoint:node.position toNode:self];
		if(pt.y < -(h)){
			node.position = CGPointMake(node.position.x, node.position.y+(h*2));
			node.zRotation = 0;
		}
	}];
	
	//その他の車
	[road enumerateChildNodesWithName:kOtherCarName usingBlock:^(SKNode *node, BOOL *stop) {
		CGPoint pt = [road convertPoint:node.position toNode:self];
		if(pt.y < -(h) || pt.y > h){
			//画面外の車を削除
			[node removeFromParent];
		}else{
			//ベクトルを加える
			NSDictionary* dic = node.userData;
			node.physicsBody.velocity = CGVectorMake(0, [dic[@"speed"] floatValue]);
		}
	}];
	
	//走行距離
	self.distance = (playerCar.position.y-_carStartPt.y)/100;
	SKLabelNode*	dist = (SKLabelNode*)[self childNodeWithName:kDistLabelName];
	dist.text = [NSString stringWithFormat:@"%.0f m", self.distance];
}


//車のランダム作成
- (void) addOtherCar
{
	if(_gameOver){
		return;
	}
	if(_accelete > 400){
		//プレイヤーカーを検索
		SKNode*		road = [self childNodeWithName:kRoadName];
		SKSpriteNode*	reacingCar = (SKSpriteNode*)[road childNodeWithName:kPlayerCarName];
		SKSpriteNode *car = [SKSpriteNode spriteNodeWithImageNamed:@"OtherCar.png"];
		//速度をランダムに作成してuserDataに保存する
		car.userData = [@{@"speed":@(skRand(200, 400))} mutableCopy];
		//横位置をランダム、プレイヤーカーの１画面分上に配置する
		car.position = CGPointMake(skRand(40, 240)-140, reacingCar.position.y+self.size.height);
		car.name = kOtherCarName;
		[road addChild:car];
		car.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:car.size];
		car.physicsBody.affectedByGravity = NO;//重力適用なし
		//接触設定
		//カテゴリー（その他の車）
		car.physicsBody.categoryBitMask = otherCarCategory;
		//接触できるオブジェクト
		car.physicsBody.collisionBitMask = playerCarCategory|otherCarCategory|wallCategory;
		//ヒットテストするオブジェクト
		car.physicsBody.contactTestBitMask = playerCarCategory;
	}
	
}
static inline CGFloat skRand(CGFloat low, CGFloat high)
{
	CGFloat	res = skRandf() * ((high - low) + low);
	return res;
}
static inline CGFloat skRandf()
{
	return rand() / (CGFloat) RAND_MAX;
}



#pragma mark - SKPhysicsContactDelegate

//衝突開始
- (void)didBeginContact:(SKPhysicsContact *)contact
{
	NSString*	bodyNameB = contact.bodyB.node.name;
	//その他の車に接触
	if([bodyNameB isEqualToString:kOtherCarName]){
		SKNode*			road = [self childNodeWithName:kRoadName];
		CGPoint pt = [self convertPoint:contact.contactPoint toNode:road];
		[self makeFireParticle:pt];
		[self makeSmokeParticle:pt];
		//ゲームオーバー
		[self showGameOver];
	}
	//プレイヤーカーが壁に接触
	if([bodyNameB isEqualToString:kPlayerCarName]){
		SKNode*			road = [self childNodeWithName:kRoadName];
		CGPoint pt = [self convertPoint:contact.contactPoint toNode:road];
		[self makeSparkParticle:pt];
	}
}

//ゲームオーバー
-(void) showGameOver
{
	if(_gameOver==NO){
		//プレイヤーカーを検索
		SKNode*		road = [self childNodeWithName:kRoadName];
		SKSpriteNode*	reacingCar = (SKSpriteNode*)[road childNodeWithName:kPlayerCarName];
		self.physicsWorld.speed = 0;	//物理シミュレーション停止
		_gameOver = YES;				//ゲームオーバーフラグ
		SKLabelNode *gameOverLabel = [SKLabelNode labelNodeWithFontNamed:@"Baskerville-Bold"];
		gameOverLabel.text = @"GAME OVER";
		gameOverLabel.fontSize = 30;
		gameOverLabel.position = CGPointMake(CGRectGetMidX(self.frame),
											 reacingCar.position.y+160);
		[road addChild:gameOverLabel];
	}
}




//炎パーティクル作成
-(void)makeFireParticle:(CGPoint)point
{
	if(_particleFire==nil){
		SKNode*		road = [self childNodeWithName:kRoadName];
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Fire" ofType:@"sks"];
		_particleFire = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
		_particleFire.numParticlesToEmit = 350;
		[road addChild:_particleFire];
	}
	else{
		[_particleFire resetSimulation];
	}
	_particleFire.position = point;
}
//スパークパーティクル作成
-(void)makeSparkParticle:(CGPoint)point
{
	if(_particleSpark==nil){
		SKNode*		road = [self childNodeWithName:kRoadName];
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Spark" ofType:@"sks"];
		_particleSpark = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
		_particleSpark.numParticlesToEmit = 100;
		[road addChild:_particleSpark];
	}
	else{
		[_particleSpark resetSimulation];
	}
	_particleSpark.position = point;
}
//スモークパーティクル作成
-(void)makeSmokeParticle:(CGPoint)point
{
	if(_particleSmoke==nil){
		SKNode*		road = [self childNodeWithName:kRoadName];
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Smoke" ofType:@"sks"];
		_particleSmoke = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
		[road addChild:_particleSmoke];
	}
	else{
		[_particleSmoke resetSimulation];
	}
	_particleSmoke.position = point;
}


@end
