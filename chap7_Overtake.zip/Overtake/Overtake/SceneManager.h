﻿//
//  SceneManager.h
//

#import <Foundation/Foundation.h>
#import "TitleScene.h"
#import "GameScene.h"
#import "ResultScene.h"

@interface SceneManager : NSObject

+(TitleScene*)titleScene:(CGSize)size;
+(GameScene*)gameScene:(CGSize)size;
+(ResultScene*)resultScene:(CGSize)size;

+(void)sceneChange:(SKView*)view
			   New:(SKScene*)newScene
		  Duration:(NSTimeInterval)sec;
@end
