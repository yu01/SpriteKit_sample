﻿//
//  GameView.m
//

#import "GameView.h"
#import "SceneManager.h"

@implementation GameView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setUpGameView];
    }
    return self;
}

-(void)awakeFromNib
{
	[self setUpGameView];
}

-(void) setUpGameView
{
    //self.showsFPS = YES;
    //self.showsNodeCount = YES;
	//タイトル画面
	[self switchingTitleScene];
}

//シーンの切り替え
//タイトル
-(void) switchingTitleScene
{
    TitleScene * scene = [SceneManager titleScene:self.bounds.size];
	scene.delegate = self;
    scene.scaleMode = SKSceneScaleModeAspectFill;
	[SceneManager sceneChange:self New:scene Duration:0.5];
}
//ゲーム
-(void) switchingGameScene
{
    GameScene * scene = [SceneManager gameScene:self.bounds.size];
	scene.delegate = self;
    scene.scaleMode = SKSceneScaleModeAspectFill;
	[SceneManager sceneChange:self New:scene Duration:0.5];
}
//結果
-(void) switchingResultScene
{
    ResultScene * scene = [SceneManager resultScene:self.bounds.size];
	scene.delegate = self;
    scene.scaleMode = SKSceneScaleModeAspectFill;
	[SceneManager sceneChange:self New:scene Duration:0.5];
}


#pragma mark - SceneEscapeProtocol

//デリゲートメソッド
-(void)sceneEscape:(SKScene *)scene
{
	if([scene isKindOfClass:[TitleScene class]]){
		[self switchingGameScene];		//ゲーム
	}
	else if([scene isKindOfClass:[GameScene class]]){
		[self switchingResultScene];	//結果
	}
	else if([scene isKindOfClass:[ResultScene class]]){
		[self switchingTitleScene];		//タイトル
	}
}

@end
