﻿//
//  GameScene.h
//

#import <SpriteKit/SpriteKit.h>

//オブジェクト名
#define		kRoadName			@"Road"				//道路
#define		kWallName			@"Wall"				//壁（ガードレール）
#define		kPlayerCarName		@"PlayerCar"		//プレイヤーカー
#define		kOtherCarName		@"OtherCar"			//その他の車

#define		kRoadViewName		@"RoadView"			//道路（表示スプライト）

#define		kDistLabelName		@"DistLabel"		//距離

//カテゴリビットマスク
static const uint32_t wallCategory		=  0x1 << 0;	//壁（ガードレール）
static const uint32_t playerCarCategory	=  0x1 << 1;	//プレイヤーカー
static const uint32_t otherCarCategory	=  0x1 << 2;	//その他の車

@interface GameScene : SKScene<SKPhysicsContactDelegate>
@property	(weak, nonatomic)	id		delegate;
@property	(assign, nonatomic)	CGFloat	distance;
@end
